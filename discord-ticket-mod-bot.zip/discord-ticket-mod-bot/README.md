# Discord Ticket + Moderation Bot

Features:
- `/ticketpanel` creates a ticket button panel
- Private ticket channels
- `/close` closes tickets
- `/kick` kicks members
- `/ban` bans members
- Deletes Discord invite links from non-mods
- Anti-spam timeout
- Small Express website so it can run through a web host

## Setup

1. Install Node.js 18+.
2. Create a Discord application and bot in the Discord Developer Portal.
3. Enable these bot privileged intents:
   - Server Members Intent
   - Message Content Intent
4. Copy `.env.example` to `.env` and fill in:
   - `DISCORD_TOKEN`
   - `CLIENT_ID`
   - `GUILD_ID`
5. Install packages:

```bash
npm install
```

6. Deploy slash commands:

```bash
npm run deploy
```

7. Start the bot:

```bash
npm start
```

## Invite permissions

When inviting the bot, give it:
- Manage Channels
- Kick Members
- Ban Members
- Manage Messages
- Moderate Members
- Read Messages/View Channels
- Send Messages

The bot role must be above the roles it should kick/ban/time out.
