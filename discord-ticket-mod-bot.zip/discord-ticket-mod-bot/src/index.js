require('dotenv').config();
const express = require('express');
const {
  Client,
  GatewayIntentBits,
  Partials,
  ChannelType,
  PermissionFlagsBits,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  Events
} = require('discord.js');

const TOKEN = process.env.DISCORD_TOKEN;
const PORT = process.env.PORT || 3000;

if (!TOKEN) throw new Error('Missing DISCORD_TOKEN in .env');

// Small website / keep-alive page
const app = express();
app.get('/', (_req, res) => res.send(`
  <h1>Discord Bot Online</h1>
  <p>Ticket + moderation bot is running.</p>
`));
app.listen(PORT, () => console.log(`Website running on port ${PORT}`));

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ],
  partials: [Partials.Channel]
});

// Basic anti-spam memory: userId -> timestamps
const spamMap = new Map();
const SPAM_LIMIT = 5;       // max messages
const SPAM_WINDOW = 7000;   // in ms
const TIMEOUT_MS = 60_000;  // 1 minute timeout
const INVITE_REGEX = /(discord\.gg\/|discord\.com\/invite\/|discordapp\.com\/invite\/)/i;

client.once(Events.ClientReady, () => {
  console.log(`Logged in as ${client.user.tag}`);
});

client.on(Events.MessageCreate, async (message) => {
  if (!message.guild || message.author.bot) return;

  const member = message.member;
  const isMod = member.permissions.has(PermissionFlagsBits.ManageMessages);

  // Block Discord invite links from non-mods
  if (!isMod && INVITE_REGEX.test(message.content)) {
    await message.delete().catch(() => {});
    await message.channel.send({ content: `${message.author}, Discord invite links are not allowed here.` })
      .then(msg => setTimeout(() => msg.delete().catch(() => {}), 5000));
    return;
  }

  // Anti-spam from non-mods
  if (!isMod) {
    const now = Date.now();
    const timestamps = spamMap.get(message.author.id) || [];
    const recent = timestamps.filter(t => now - t < SPAM_WINDOW);
    recent.push(now);
    spamMap.set(message.author.id, recent);

    if (recent.length > SPAM_LIMIT) {
      await message.delete().catch(() => {});
      await member.timeout(TIMEOUT_MS, 'Anti-spam triggered').catch(() => {});
      await message.channel.send({ content: `${message.author} was timed out for spamming.` })
        .then(msg => setTimeout(() => msg.delete().catch(() => {}), 5000));
    }
  }
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (interaction.isChatInputCommand()) {
    if (interaction.commandName === 'ticketpanel') {
      const embed = new EmbedBuilder()
        .setTitle('Support Tickets')
        .setDescription('Click the button below to create a private ticket.')
        .setColor(0x5865F2);

      const button = new ButtonBuilder()
        .setCustomId('create_ticket')
        .setLabel('Create Ticket')
        .setStyle(ButtonStyle.Primary);

      await interaction.reply({ embeds: [embed], components: [new ActionRowBuilder().addComponents(button)] });
    }

    if (interaction.commandName === 'close') {
      if (!interaction.channel.name.startsWith('ticket-')) {
        return interaction.reply({ content: 'This command only works inside a ticket channel.', ephemeral: true });
      }
      await interaction.reply('Closing ticket in 5 seconds...');
      setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
    }

    if (interaction.commandName === 'kick') {
      const target = interaction.options.getMember('user');
      const reason = interaction.options.getString('reason') || 'No reason provided';
      if (!target) return interaction.reply({ content: 'User not found in this server.', ephemeral: true });
      if (!target.kickable) return interaction.reply({ content: 'I cannot kick this user. Check my role position and permissions.', ephemeral: true });
      await target.kick(reason);
      await interaction.reply(`Kicked ${target.user.tag}. Reason: ${reason}`);
    }

    if (interaction.commandName === 'ban') {
      const target = interaction.options.getMember('user');
      const reason = interaction.options.getString('reason') || 'No reason provided';
      if (!target) return interaction.reply({ content: 'User not found in this server.', ephemeral: true });
      if (!target.bannable) return interaction.reply({ content: 'I cannot ban this user. Check my role position and permissions.', ephemeral: true });
      await target.ban({ reason });
      await interaction.reply(`Banned ${target.user.tag}. Reason: ${reason}`);
    }
  }

  if (interaction.isButton() && interaction.customId === 'create_ticket') {
    const existing = interaction.guild.channels.cache.find(c => c.name === `ticket-${interaction.user.id}`);
    if (existing) return interaction.reply({ content: `You already have a ticket: ${existing}`, ephemeral: true });

    const channel = await interaction.guild.channels.create({
      name: `ticket-${interaction.user.id}`,
      type: ChannelType.GuildText,
      permissionOverwrites: [
        { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
        { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
        { id: interaction.client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels] }
      ]
    });

    await channel.send(`Welcome ${interaction.user}. Staff will help you soon. Use /close to close this ticket.`);
    await interaction.reply({ content: `Ticket created: ${channel}`, ephemeral: true });
  }
});

client.login(TOKEN);
